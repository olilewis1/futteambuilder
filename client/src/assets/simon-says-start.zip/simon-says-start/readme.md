## SIMON SAYS

Your job is to add the JS to make the game work

**Key features**

* Computer should generate a random sequence
* The sequence should animate in order
* Player needs to repeat the sequence by clicking on the coloured buttons
* If player makes a wrong move, game over
* If player gets the sequence correct then a new longer sequence should generate


I have added a cdn link for Animate.css so you can use the classes to animate the buttons. Documentation can be found here:
https://animate.style/

Feel free to change the CSS or add in any extra things you would like!

**hint**: you will need some timers for this one!