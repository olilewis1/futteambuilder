function init() {
  console.log('JS is up and running!')







}

document.addEventListener('DOMContentLoaded', init)